import React, { useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { 
  faPlay, 
  faStop, 
  faGlobe, 
  faTerminal, 
  faSun, 
  faMoon, 
  faSliders, 
  faPlus, 
  faBookOpen, 
  faCircleQuestion, 
  faDownload,
  faCode,
  faTrash,
  faRobot,
  faGamepad
} from '@fortawesome/free-solid-svg-icons';
import type { ThemeMode } from '../types';
import './Toolbar.css';

interface ToolbarProps {
  isRunning: boolean;
  isPlaying?: boolean;
  onPlay: () => void;
  onRun: () => void;
  onStop: () => void;
  isExplorerOpen: boolean;
  onToggleExplorer: () => void;
  isConsoleOpen: boolean;
  onToggleConsole: () => void;
  theme: ThemeMode;
  onToggleTheme: () => void;
  onOpenSettings: () => void;
  onOpenNewScript: () => void;
  onDeleteActiveScript?: () => void;
  onOpenExamples: () => void;
  onOpenDocs: () => void;
  onDownloadZip: () => void;
  onOpenAiAgent: () => void;
}

const BRAND_ICON_URL = "/app-icon.png";

const Toolbar: React.FC<ToolbarProps> = ({
  isRunning,
  isPlaying = false,
  onPlay,
  onRun,
  onStop,
  isExplorerOpen,
  onToggleExplorer,
  isConsoleOpen,
  onToggleConsole,
  theme,
  onToggleTheme,
  onOpenSettings,
  onOpenNewScript,
  onDeleteActiveScript,
  onOpenExamples,
  onOpenDocs,
  onDownloadZip,
  onOpenAiAgent,
}) => {
  const isDark = theme === 'dark';
  const [imgError, setImgError] = useState(false);
  const isExecutionActive = isRunning || isPlaying;

  return (
    <header className={`app-toolbar ${isDark ? 'dark' : 'light'}`}>
      {/* Brand & Logo */}
      <div className="toolbar-brand">
        {!imgError ? (
          <img 
            src={BRAND_ICON_URL} 
            alt="Luau Runner Logo" 
            className="brand-logo" 
            onError={() => setImgError(true)}
          />
        ) : (
          <div className="brand-logo-fallback">
            <FontAwesomeIcon icon={faCode} />
          </div>
        )}
        <div className="brand-info">
          <span className="brand-title">LUAU RUNNER</span>
          <span className="brand-sub">Roblox Engine</span>
        </div>
      </div>

      <div className="toolbar-divider" />

      {/* Primary Actions: Play, Run & Stop */}
      <div className="toolbar-section primary-actions">
        {!isExecutionActive ? (
          <>
            <button 
              className="toolbar-btn btn-play" 
              onClick={onPlay} 
              title="Play Solo: Launch 3D Roblox Viewport with character avatar (F5)"
            >
              <FontAwesomeIcon icon={faGamepad} />
              <span className="btn-text">Play</span>
            </button>
            <button 
              className="toolbar-btn btn-run" 
              onClick={onRun} 
              title="Run: Execute server-side script in console (F8 / Ctrl+Enter)"
            >
              <FontAwesomeIcon icon={faPlay} />
              <span className="btn-text">Run</span>
            </button>
          </>
        ) : (
          <button 
            className="toolbar-btn btn-stop" 
            onClick={onStop} 
            title="Stop execution and return to code editor (Shift+F5)"
          >
            <FontAwesomeIcon icon={faStop} />
            <span className="btn-text">Stop</span>
          </button>
        )}

        {/* AI Agent Button */}
        <button
          className="toolbar-btn btn-ai-agent"
          onClick={onOpenAiAgent}
          title="Luau AI Agent (Powered by OpenRouter) - Generate, Edit, or Optimize code"
        >
          <FontAwesomeIcon icon={faRobot} />
          <span className="btn-text">AI Agent</span>
        </button>
      </div>

      <div className="toolbar-divider" />

      {/* Editor & View Tools */}
      <div className="toolbar-section">
        {/* SMALL GLOBE/EARTH ICON TOGGLES EXPLORER */}
        <button 
          className={`toolbar-btn ${isExplorerOpen ? 'active' : ''}`}
          onClick={onToggleExplorer}
          title="Toggle Explorer hierarchy (Font Awesome Globe)"
        >
          <FontAwesomeIcon icon={faGlobe} />
          <span className="btn-text">Explorer</span>
        </button>

        {/* Toggle Console */}
        <button 
          className={`toolbar-btn ${isConsoleOpen ? 'active' : ''}`}
          onClick={onToggleConsole}
          title="Toggle Output Console"
        >
          <FontAwesomeIcon icon={faTerminal} />
          <span className="btn-text">Console</span>
        </button>
      </div>

      <div className="toolbar-divider" />

      {/* Scripts & File Management */}
      <div className="toolbar-section">
        <button 
          className="toolbar-btn" 
          onClick={onOpenNewScript}
          title="Create new script (choose from 4 types)"
        >
          <FontAwesomeIcon icon={faPlus} />
          <span className="btn-text">New Script</span>
        </button>

        <button 
          className="toolbar-btn" 
          onClick={onOpenExamples}
          title="Load working example scripts"
        >
          <FontAwesomeIcon icon={faBookOpen} />
          <span className="btn-text">Examples</span>
        </button>

        {onDeleteActiveScript && (
          <button 
            className="toolbar-btn btn-delete-script" 
            onClick={onDeleteActiveScript}
            title="Delete current active script"
          >
            <FontAwesomeIcon icon={faTrash} />
            <span className="btn-text">Delete</span>
          </button>
        )}
      </div>

      <div className="toolbar-spacer" />

      {/* Right-side Utilities */}
      <div className="toolbar-section right-actions">
        <button 
          className="toolbar-btn" 
          onClick={onOpenDocs}
          title="Luau & Roblox API Documentation"
        >
          <FontAwesomeIcon icon={faCircleQuestion} />
          <span className="btn-text">Docs</span>
        </button>

        <button 
          className="toolbar-btn" 
          onClick={onDownloadZip}
          title="Download complete project ZIP file"
        >
          <FontAwesomeIcon icon={faDownload} />
          <span className="btn-text">Export ZIP</span>
        </button>

        <button 
          className="toolbar-btn" 
          onClick={onOpenSettings}
          title="Editor & Runner Settings"
        >
          <FontAwesomeIcon icon={faSliders} />
        </button>

        <button 
          className="toolbar-btn theme-toggle" 
          onClick={onToggleTheme}
          title={isDark ? "Switch to Light Theme" : "Switch to Dark Theme"}
        >
          <FontAwesomeIcon icon={isDark ? faSun : faMoon} />
        </button>
      </div>
    </header>
  );
};

export default Toolbar;
